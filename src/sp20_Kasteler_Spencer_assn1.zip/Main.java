public class Main {

    public static void main(String[] args) {
        int RANDOMCT = 7;
        LadderGame g = new LadderGame("dictionary.txt");

        //g.play("oops", "tots");
        //g.play("ride", "ands");
        //g.play("happily", "angrily");
        //g.play("tire", "fire");
        //g.play("slow", "fast");
        //g.play("stone", "money");
        g.play("biff", "axal");
        //for (int i = 3; i < RANDOMCT; i++)
        //            g.play(i);
                        }
}
